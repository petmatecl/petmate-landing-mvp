import React, { useState } from 'react';
import { supabase } from '../lib/supabaseClient';

type Props = {
    role: "cliente" | "sitter" | "client" | null; // supporting legacy "client" string
    text?: string;
    source?: 'login' | 'register';
};

export default function LinkedInAuthButton({ role, text = "Continuar con LinkedIn", source = 'login' }: Props) {
    const [loading, setLoading] = useState(false);

    const handleLinkedInLogin = async () => {
        try {
            if (!role) {
                alert("Por favor selecciona si buscas cuidado (Usuario) o quieres cuidar (Proveedor).");
                return;
            }

            setLoading(true);
            // Save role to handle redirection/profile creation after callback
            // (Shared logic with GoogleAuthButton)
            if (typeof window !== 'undefined') {
                window.localStorage.setItem('pm_auth_role_pending', role);
            }

            const { error } = await supabase.auth.signInWithOAuth({
                provider: 'linkedin_oidc', // Using the modern OIDC provider string if supported, or just 'linkedin'
                options: {
                    redirectTo: `${window.location.origin}/email-confirmado?flow=${source}`,
                },
            });

            if (error) throw error;
        } catch (error) {
            console.error("Error logging in with LinkedIn:", error);
            alert("Error al iniciar con LinkedIn. Verifica la configuración o intenta más tarde.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <button
            type="button"
            onClick={handleLinkedInLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 bg-[#0a66c2] hover:bg-[#004182] text-white font-bold py-3 px-4 rounded-xl transition-all shadow-sm border border-transparent mt-3"
        >
            {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : (
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
            )}
            {text}
        </button>
    );
}
