import { useEffect, useState } from "react";
import Head from "next/head";
import { useRouter } from "next/router";
import { supabase } from "../../lib/supabaseClient";
import Link from "next/link";
import { ArrowLeft, Bell, Calendar, ChevronRight, User } from "lucide-react";
import AdminLayout from "../../components/Admin/AdminLayout";

export default function AdminNotifications() {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        proveedoresPendientes: 0,
        solicitudesPendientes: 0
    });
    const [activities, setActivities] = useState<any[]>([]);


    const fetchData = async () => {
        // 1. Stats Counters
        const { count: proveedoresPendientes } = await supabase
            .from("proveedores")
            .select("*", { count: "exact", head: true })
            .eq("estado", "pendiente");

        const { count: solicitudesPendientes } = await supabase
            .from("viajes")
            .select("*", { count: "exact", head: true })
            .is("sitter_id", null)
            .neq("estado", "cancelado")
            .neq("estado", "completado");

        setStats({
            proveedoresPendientes: proveedoresPendientes || 0,
            solicitudesPendientes: solicitudesPendientes || 0
        });

        // 2. Recent Activity — combinar proveedores y usuarios recientes
        const { data: recentProveedores } = await supabase
            .from('proveedores')
            .select('id, nombre, apellido_p, created_at, estado')
            .order('created_at', { ascending: false })
            .limit(10);

        const { data: recentBuscadores } = await supabase
            .from('usuarios_buscadores')
            .select('id, nombre, apellido_p, created_at')
            .order('created_at', { ascending: false })
            .limit(10);

        const combined = [
            ...(recentProveedores || []).map(p => ({ ...p, tipo: 'proveedor' })),
            ...(recentBuscadores || []).map(b => ({ ...b, tipo: 'usuario', estado: null })),
        ]
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
            .slice(0, 20);

        setActivities(combined);
    };

    const checkAuth = async () => {
        setLoading(true);
        const { data: { session } } = await supabase.auth.getSession();

        if (!session) {
            router.push("/login");
            return;
        }


        await fetchData();
        setLoading(false);
    };

    useEffect(() => {
        checkAuth();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <AdminLayout>
            <Head>
                <title>Notificaciones | Admin Pawnecta</title>
            </Head>

            <div className="w-full pb-20">
                {/* Header with Back Button */}
                <div className="mb-8 flex items-center gap-4">
                    <button
                        onClick={() => router.back()}
                        className="p-2 bg-white border-2 border-slate-300 rounded-full hover:bg-slate-50 transition-colors"
                    >
                        <ArrowLeft size={20} className="text-slate-600" />
                    </button>
                    <div>
                        <h1 className="text-2xl font-bold text-slate-900">Centro de Notificaciones</h1>
                        <p className="text-slate-500">Actividad reciente y tareas pendientes</p>
                    </div>
                </div>

                {loading ? (
                    <div className="flex h-64 items-center justify-center">
                        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-emerald-600"></div>
                    </div>
                ) : (
                    <div className="space-y-8">

                        {/* Quick Actions / Pending Stats */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-amber-100 relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-amber-50 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                                <div className="relative z-10">
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="bg-amber-100 p-2 rounded-lg text-amber-600">
                                            <User size={20} />
                                        </div>
                                        <p className="font-bold text-slate-600 uppercase text-xs tracking-wider">Proveedores Pendientes</p>
                                    </div>
                                    <p className="text-4xl font-extrabold text-slate-900">{stats.proveedoresPendientes}</p>
                                    <Link href="/admin/proveedores?estado=pendiente" className="mt-4 text-amber-600 font-bold text-sm hover:underline flex items-center gap-1">
                                        Revisar solicitudes <ChevronRight size={14} />
                                    </Link>
                                </div>
                            </div>

                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-indigo-100 relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                                <div className="relative z-10">
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600">
                                            <Calendar size={20} />
                                        </div>
                                        <p className="font-bold text-slate-600 uppercase text-xs tracking-wider">Solicitudes sin Proveedor</p>
                                    </div>
                                    <p className="text-4xl font-extrabold text-slate-900">{stats.solicitudesPendientes}</p>
                                    <Link href="/admin?tab=solicitudes&filter=pending" className="mt-4 text-indigo-600 font-bold text-sm hover:underline flex items-center gap-1">
                                        Gestionar viajes <ChevronRight size={14} />
                                    </Link>
                                </div>
                            </div>
                        </div>

                        {/* Recent Activity Feed */}
                        <div className="bg-white rounded-2xl shadow-sm border-2 border-slate-300 overflow-hidden">
                            <div className="p-6 border-b border-slate-300 flex items-center gap-2">
                                <Bell className="text-slate-400" size={20} />
                                <h3 className="font-bold text-lg text-slate-900">Últimos Registros</h3>
                            </div>
                            <div className="divide-y divide-slate-100">
                                {activities.map((user) => (
                                    <div key={user.id} className="p-4 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                                        <div className={`h-10 w-10 rounded-full flex items-center justify-center font-bold text-sm uppercase shrink-0
                                            ${user.tipo === 'proveedor' ? 'bg-emerald-100 text-emerald-600' : 'bg-blue-100 text-blue-600'}
                                        `}>
                                            {user.nombre?.[0] || "?"}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium text-slate-900 truncate">
                                                <span className="font-bold">{user.nombre} {user.apellido_p}</span> se registró como {user.tipo === 'proveedor' ? 'Proveedor' : 'Usuario'}.
                                            </p>
                                            <p className="text-xs text-slate-500">
                                                {new Date(user.created_at).toLocaleString('es-CL')}
                                            </p>
                                        </div>

                                        {user.tipo === 'proveedor' ? (
                                            user.estado === 'aprobado' ? (
                                                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 uppercase tracking-wide">
                                                    Aprobado
                                                </span>
                                            ) : (
                                                <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 uppercase tracking-wide">
                                                    Pendiente
                                                </span>
                                            )
                                        ) : (
                                            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 uppercase tracking-wide">
                                                Usuario
                                            </span>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>

                    </div>
                )}
            </div>
        </AdminLayout>
    );
}
