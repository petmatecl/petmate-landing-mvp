import React, { useState, useRef, useEffect } from "react";
import Head from "next/head";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/router";
import {
  Search, Briefcase, CheckCircle2, Eye, EyeOff, ArrowLeft, Loader2,
  Stethoscope, Car, Scissors, GraduationCap, Home, Sun, Footprints, MapPin
} from "lucide-react";
import { supabase } from "../lib/supabaseClient";
import { validateRut, formatRut } from "../lib/rutValidation";
import { COMUNAS_CHILE } from "../lib/comunas";

type TipoCampo = 'text' | 'select' | 'boolean' | 'number';

interface CampoDinamico {
  key: string;
  label: string;
  tipo: "text" | "number" | "boolean" | "select" | "textarea";
  placeholder?: string;
  requerido?: boolean;
  opciones?: { value: string; label: string }[];
  condicionalDe?: string;
  condicionalValor?: string | boolean | number;
}

const CAMPOS_POR_CATEGORIA: Record<string, CampoDinamico[]> = {
  veterinario: [
    { key: 'universidad', label: 'Universidad donde estudió', tipo: 'text', placeholder: 'Ej: Universidad de Chile', requerido: true },
    { key: 'anio_titulacion', label: 'Año de titulación', tipo: 'number', placeholder: 'Ej: 2018' },
    { key: 'numero_registro', label: 'N° de registro profesional', tipo: 'text', placeholder: 'Ej: 12345' },
    { key: 'especialidad', label: 'Especialidad (opcional)', tipo: 'text', placeholder: 'Ej: Dermatología, Cirugía...' },
  ],
  traslado: [
    {
      key: 'tipo_vehiculo', label: 'Tipo de vehículo', tipo: 'select',
      opciones: [{ value: 'auto', label: 'Auto' }, { value: 'van', label: 'Van' }, { value: 'furgon', label: 'Furgón' }], requerido: true
    },
    { key: 'tiene_empresa', label: 'Opero con empresa/boleta', tipo: 'boolean' },
    { key: 'nombre_empresa', label: 'Nombre de empresa (si aplica)', tipo: 'text', placeholder: 'Ej: Transportes Patitas SpA' },
    { key: 'capacidad_mascotas', label: 'Capacidad máx. de mascotas', tipo: 'number', placeholder: 'Ej: 3' },
  ],
  peluqueria: [
    { key: 'anios_experiencia', label: 'Años de experiencia', tipo: 'number', placeholder: 'Ej: 5', requerido: true },
    { key: 'certificaciones', label: 'Certificaciones o cursos', tipo: 'text', placeholder: 'Ej: Curso Groomex 2022' },
    { key: 'tiene_local', label: 'Tengo local propio', tipo: 'boolean' },
  ],
  adiestramiento: [
    {
      key: 'metodo', label: 'Método de adiestramiento', tipo: 'select',
      opciones: [{ value: 'positivo', label: 'Refuerzo positivo' }, { value: 'mixto', label: 'Mixto' }, { value: 'tradicional', label: 'Tradicional' }], requerido: true
    },
    { key: 'anios_experiencia', label: 'Años de experiencia', tipo: 'number', placeholder: 'Ej: 3' },
    { key: 'certificacion', label: 'Certificación (si tiene)', tipo: 'text', placeholder: 'Ej: CPDT-KA' },
  ],
  hospedaje: [
    {
      key: "tipo_vivienda", label: "Tipo de vivienda donde cuidas", tipo: "select",
      opciones: [{ value: "casa", label: "Casa" }, { value: "departamento", label: "Departamento" }],
      requerido: true
    },
    {
      key: "metros_espacio", label: "Metros cuadrados del espacio disponible para la mascota",
      tipo: "number", placeholder: "Ej: 30"
    },
    {
      key: "capacidad_maxima", label: "Capacidad maxima (mascotas simultaneas)",
      tipo: "number", placeholder: "Ej: 2", requerido: true
    },
    { key: "tiene_patio", label: "Tengo patio o jardin con acceso directo", tipo: "boolean" },
    {
      key: "piso_departamento", label: "Piso del departamento", tipo: "number",
      placeholder: "Ej: 5",
      condicionalDe: "tipo_vivienda", condicionalValor: "departamento"
    },
    {
      key: "tiene_mallas_seguridad", label: "Tengo mallas de seguridad en ventanas y balcones",
      tipo: "boolean",
      condicionalDe: "tipo_vivienda", condicionalValor: "departamento"
    },
    { key: "otras_mascotas_hogar", label: "Tengo mascotas propias en el hogar", tipo: "boolean" },
    {
      key: "tipo_mascotas_propias", label: "Que mascotas tienes? (describe)",
      tipo: "text", placeholder: "Ej: 1 gato castrado tranquilo",
      condicionalDe: "otras_mascotas_hogar", condicionalValor: true
    },
    { key: "tiene_ninos", label: "Hay ninos menores de 12 anos en el hogar", tipo: "boolean" },
    { key: "acepta_separacion", label: "Puedo mantener mascotas separadas si es necesario", tipo: "boolean" },
  ],
  guarderia: [
    { key: 'capacidad_maxima', label: 'Capacidad máxima (mascotas)', tipo: 'number', placeholder: 'Ej: 5', requerido: true },
    { key: 'tiene_patio', label: 'Tengo patio o jardín', tipo: 'boolean' },
    { key: 'horario', label: 'Horario de atención', tipo: 'text', placeholder: 'Ej: Lunes a viernes 8:00 - 18:00' },
  ],
  paseos: [
    { key: 'max_perros_simultaneos', label: 'Máximo de perros simultáneos', tipo: 'number', placeholder: 'Ej: 3', requerido: true },
    { key: 'duracion_estandar', label: 'Duración estándar del paseo (minutos)', tipo: 'number', placeholder: 'Ej: 45' },
  ],
  domicilio: [
    {
      key: "anios_experiencia", label: "Anos de experiencia en cuidado de mascotas",
      tipo: "number", placeholder: "Ej: 4"
    },
    {
      key: "visitas_por_dia", label: "Visitas por dia que puedes hacer",
      tipo: "number", placeholder: "Ej: 2", requerido: true
    },
    {
      key: "duracion_visita", label: "Duracion de cada visita (minutos)",
      tipo: "number", placeholder: "Ej: 45", requerido: true
    },
    {
      key: "servicios_incluidos", label: "Que incluye cada visita",
      tipo: "text", placeholder: "Ej: Alimentacion, paseo corto, limpieza, compania"
    },
    {
      key: "incluye_medicamentos", label: "Puedo administrar medicamentos orales segun instrucciones",
      tipo: "boolean"
    },
    { key: "incluye_foto_reporte", label: "Envio foto + reporte de cada visita", tipo: "boolean" },
    {
      key: "experiencia_emergencias", label: "Tengo experiencia en emergencias basicas",
      tipo: "boolean"
    },
  ],
};

const CATEGORIA_ICONS: Record<string, React.ElementType> = {
  veterinario: Stethoscope,
  traslado: Car,
  peluqueria: Scissors,
  adiestramiento: GraduationCap,
  hospedaje: Home,
  guarderia: Sun,
  paseos: Footprints,
  domicilio: MapPin,
};

type Role = "usuario" | "proveedor";

const CATEGORIES = [
  { value: 'hospedaje', label: 'Hospedaje' },
  { value: 'guarderia', label: 'Guardería Diurna' },
  { value: 'paseos', label: 'Paseo de Perros' },
  { value: 'domicilio', label: 'Cuidado a Domicilio' },
  { value: 'peluqueria', label: 'Peluquería' },
  { value: 'adiestramiento', label: 'Adiestramiento' },
  { value: 'veterinario', label: 'Veterinario a Domicilio' },
  { value: 'traslado', label: 'Traslado' },
];


export default function RegisterWizard() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Step 1: Role
  const [rol, setRol] = useState<Role | null>(null);

  // Step 2: Personal Info
  const [nombre, setNombre] = useState('');
  const [apellidoP, setApellidoP] = useState('');
  const [apellidoM, setApellidoM] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordConfirm, setShowPasswordConfirm] = useState(false);

  // Step 2+3: RUT (common)
  const [rut, setRut] = useState('');
  const [rutError, setRutError] = useState('');

  // Step 3: Provider Info
  const [comunaQuery, setComunaQuery] = useState('');
  const [showComunaList, setShowComunaList] = useState(false);
  const [categoria, setCategoria] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [aceptaPolitica, setAceptaPolitica] = useState(false);

  // Step 3: Datos dinámicos por categoría
  const [datosDinamicos, setDatosDinamicos] = useState<Record<string, any>>({});
  const setDatoDinamico = (key: string, value: any) =>
    setDatosDinamicos(prev => ({ ...prev, [key]: value }));
  const comunaRef = useRef<HTMLDivElement>(null);

  const comunasFiltradas = COMUNAS_CHILE.filter(c =>
    c.toLowerCase().includes(comunaQuery.toLowerCase())
  ).slice(0, 8);

  // Cierra el dropdown al hacer click fuera
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (comunaRef.current && !comunaRef.current.contains(e.target as Node)) {
        setShowComunaList(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Pre-seleccionar rol desde query param ?rol=proveedor o ?rol=usuario
  useEffect(() => {
    if (!router.isReady) return;
    const queryRol = router.query.rol as string | undefined;
    if (queryRol === 'proveedor' || queryRol === 'usuario') {
      setRol(queryRol as Role);
      // Skip step 1 and go directly to step 2
      setStep(2);
    }
  }, [router.isReady, router.query.rol]);

  const proceedToStep2 = () => {
    if (!rol) {
      setError("Por favor, selecciona el tipo de cuenta que quieres crear.");
      return;
    }
    setError("");
    setStep(2);
  };

  const proceedToNextStep = () => {
    setError("");
    if (!nombre || !apellidoP || !email || !password || !passwordConfirm) {
      setError("Por favor completa los campos obligatorios.");
      return;
    }
    if (password.length < 8) {
      setError("La contraseña debe tener al menos 8 caracteres.");
      return;
    }
    if (password !== passwordConfirm) {
      setError("Las contraseñas no coinciden.");
      return;
    }
    if (!rut) {
      setError("El RUT es obligatorio para registrarse.");
      return;
    }
    if (!validateRut(rut)) {
      setError("El RUT ingresado no es válido. Verifica el número y dígito verificador.");
      setRutError("RUT inválido — verifica el número y dígito verificador.");
      return;
    }
    setRutError('');

    if (rol === "proveedor") {
      setStep(3);
    } else {
      handleFinalSubmit();
    }
  };

  const handleFinalSubmit = async () => {
    setError("");

    if (rol === 'proveedor') {
      if (!categoria) {
        setError('Por favor selecciona tu categoría principal de servicio.');
        return;
      }
    }

    if (rol === 'proveedor') {
      if (!comunaQuery.trim()) {
        setError('Por favor completa los campos obligatorios (Comuna).');
        return;
      }
      // Validate required dynamic fields
      const campos = CAMPOS_POR_CATEGORIA[categoria] || [];
      for (const campo of campos) {
        if (campo.requerido && !datosDinamicos[campo.key]) {
          setError(`El campo «${campo.label}» es obligatorio.`);
          return;
        }
      }
      if (!aceptaPolitica) {
        setError('Debes aceptar las políticas de publicación para continuar.');
        return;
      }
    }

    setLoading(true);

    // Timeout de seguridad: si el proceso tarda más de 25 segundos, resetea
    const safetyTimer = setTimeout(() => {
      setLoading(false);
      setError("La operación tardó demasiado. Verifica tu conexión e intenta nuevamente.");
    }, 25000);

    try {
      // 1. Sign up user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (authError) throw authError;

      const userId = authData.user?.id;
      if (!userId) throw new Error("No se pudo obtener el ID del usuario.");

      // 2. Insert into respective tables
      if (rol === 'usuario') {
        const { error: insertError } = await supabase.from('usuarios_buscadores').insert([{
          auth_user_id: userId,
          nombre: nombre.trim(),
          apellido_p: apellidoP.trim(),
          apellido_m: apellidoM.trim() || null,
          rut: formatRut(rut),
        }]);
        if (insertError) {
          console.error('Insert error in usuarios_buscadores:', insertError.message, insertError.code, insertError.details);
          throw new Error('Error guardando datos de usuario: ' + insertError.message);
        }
      } else if (rol === 'proveedor') {
        const { error: insertError } = await supabase.from('proveedores').insert([{
          auth_user_id: userId,
          nombre: nombre.trim(),
          apellido_p: apellidoP.trim(),
          apellido_m: apellidoM.trim() || null,
          rut: formatRut(rut),
          comuna: comunaQuery.trim(),
          roles: ['proveedor'],
          estado: 'pendiente',
          datos_especificos: Object.keys(datosDinamicos).length > 0 ? datosDinamicos : null,
        }]);
        if (insertError) {
          console.error('Insert error in proveedores:', insertError.message, insertError.code, insertError.details);
          throw new Error('Error guardando datos de proveedor: ' + insertError.message);
        }
      }

      // 3. Trigger Welcome Email API — no debe bloquear el flujo
      const welcomeController = new AbortController();
      const welcomeTimeout = setTimeout(() => welcomeController.abort(), 5000);
      try {
        await fetch('/api/auth/welcome', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, email, nombre: nombre.trim(), rol }),
          signal: welcomeController.signal,
        });
      } catch (welcomeErr) {
        console.warn('Welcome email no enviado (no bloquea el registro):', welcomeErr);
      } finally {
        clearTimeout(welcomeTimeout);
      }

      // 4. Move to Success Screen
      clearTimeout(safetyTimer);
      setStep(4);
    } catch (err: any) {
      clearTimeout(safetyTimer);
      console.error('Registration error:', err);
      setError(err.message || 'Error al completar el registro. Intenta nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  const getTotalSteps = () => rol === 'proveedor' ? 4 : 3;

  const inputClass = "w-full h-12 px-4 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 focus:bg-white placeholder:text-slate-400 transition-colors";

  return (
    <>
      <Head>
        <title>Crear cuenta — Pawnecta</title>
        <meta name="description" content="Regístrate en Pawnecta. Crea tu cuenta gratis para encontrar o publicar servicios para mascotas en Chile." />
      </Head>

      <main className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-4 py-10">
        <div className="w-full max-w-2xl bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">

          {/* Progress header */}
          <div className="bg-slate-50 border-b border-slate-100 p-6 sm:px-10 flex flex-col items-center">
            <h1 className="text-2xl font-bold text-slate-800">Crea tu cuenta en Pawnecta</h1>
            {step < 4 && (
              <div className="mt-4 flex items-center justify-center gap-2 text-sm font-medium text-slate-500">
                <span className={`w-8 h-8 flex items-center justify-center rounded-full ${step >= 1 ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100'}`}>1</span>
                <div className={`w-10 h-[2px] ${step >= 2 ? 'bg-emerald-200' : 'bg-slate-200'}`}></div>
                <span className={`w-8 h-8 flex items-center justify-center rounded-full ${step >= 2 ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100'}`}>2</span>

                {rol === 'proveedor' && (
                  <>
                    <div className={`w-10 h-[2px] ${step >= 3 ? 'bg-emerald-200' : 'bg-slate-200'}`}></div>
                    <span className={`w-8 h-8 flex items-center justify-center rounded-full ${step >= 3 ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100'}`}>3</span>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="p-6 sm:px-10 sm:py-8">
            {error && (
              <div className="p-4 mb-6 text-sm text-red-700 bg-red-50 rounded-xl border border-red-100">
                {error}
              </div>
            )}

            {/* Step 1: Role Selection */}
            {step === 1 && (
              <div className="animate-fade-in space-y-4">
                <div className="text-center mb-8">
                  <h2 className="text-lg font-semibold text-slate-800">¿Cómo quieres usar Pawnecta?</h2>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setRol('usuario')}
                    className={`flex flex-col items-center text-center p-6 border-2 rounded-2xl transition-all ${rol === 'usuario' ? 'border-emerald-600 bg-emerald-50' : 'border-slate-200 hover:border-emerald-300'}`}
                  >
                    <div className={`p-4 rounded-full mb-4 ${rol === 'usuario' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                      <Search size={32} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Busco servicios</h3>
                    <p className="text-sm text-slate-600">Encuentra proveedores verificados en tu comuna</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRol('proveedor')}
                    className={`flex flex-col items-center text-center p-6 border-2 rounded-2xl transition-all ${rol === 'proveedor' ? 'border-emerald-600 bg-emerald-50' : 'border-slate-200 hover:border-emerald-300'}`}
                  >
                    <div className={`p-4 rounded-full mb-4 ${rol === 'proveedor' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                      <Briefcase size={32} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 mb-2">Ofrezco servicios</h3>
                    <p className="text-sm text-slate-600">Publica tus servicios y recibe consultas directo</p>
                  </button>
                </div>

                <div className="pt-6">
                  <button
                    onClick={proceedToStep2}
                    className="w-full bg-emerald-700 text-white font-semibold py-4 rounded-xl hover:bg-emerald-800 transition-colors"
                  >
                    Continuar
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Personal Info (Both Roles) */}
            {step === 2 && (
              <div className="animate-fade-in space-y-5">
                <h2 className="text-lg font-semibold text-slate-800 border-b border-slate-100 pb-2">Tus datos personales</h2>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Nombre *</label>
                    <input type="text" value={nombre} onChange={e => setNombre(e.target.value)} required className={inputClass} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Apellido Paterno *</label>
                    <input type="text" value={apellidoP} onChange={e => setApellidoP(e.target.value)} required className={inputClass} />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Apellido Materno (Opcional)</label>
                  <input type="text" value={apellidoM} onChange={e => setApellidoM(e.target.value)} className={inputClass} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">RUT *</label>
                  <input
                    type="text"
                    value={rut}
                    onChange={e => {
                      setRut(formatRut(e.target.value));
                      if (rutError) setRutError('');
                    }}
                    onBlur={() => {
                      if (rut && !validateRut(rut)) {
                        setRutError('RUT inválido — verifica el número y dígito verificador.');
                      } else {
                        setRutError('');
                      }
                    }}
                    required
                    placeholder="12.345.678-9"
                    maxLength={12}
                    className={`${inputClass} ${rutError ? 'border-red-400 focus:ring-red-400 focus:border-red-400' : ''}`}
                  />
                  {rutError ? (
                    <p className="text-xs text-red-600 mt-1 font-medium">{rutError}</p>
                  ) : (
                    <p className="text-xs text-slate-500 mt-1">Solo lo usamos para verificar tu identidad. No se muestra públicamente.</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Correo Electrónico *</label>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className={inputClass} />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Contraseña *</label>
                    <div className="relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        required
                        minLength={8}
                        className={`${inputClass} pr-12`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(v => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                        aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                    <span className="text-xs text-slate-500 mt-1 block">Mínimo 8 caracteres</span>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Confirmar Contraseña *</label>
                    <div className="relative">
                      <input
                        type={showPasswordConfirm ? "text" : "password"}
                        value={passwordConfirm}
                        onChange={e => setPasswordConfirm(e.target.value)}
                        required
                        minLength={8}
                        className={`${inputClass} pr-12`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPasswordConfirm(v => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                        aria-label={showPasswordConfirm ? "Ocultar contraseña" : "Mostrar contraseña"}
                      >
                        {showPasswordConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Categoría — solo proveedores */}
                {rol === 'proveedor' && (
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Categoría principal de servicio *</label>
                    <select
                      value={categoria}
                      onChange={e => { setCategoria(e.target.value); setDatosDinamicos({}); }}
                      required
                      className={`${inputClass} cursor-pointer`}
                    >
                      <option value="" disabled>Selecciona una categoría</option>
                      {CATEGORIES.map(cat => (
                        <option key={cat.value} value={cat.value}>{cat.label}</option>
                      ))}
                    </select>
                    <p className="text-xs text-slate-500 mt-1">Podrás agregar más categorías desde tu panel después de ser aprobado.</p>
                  </div>
                )}

                <div className="pt-6 flex gap-3">
                  <button onClick={() => setStep(1)} className="w-1/3 border border-slate-300 text-slate-700 font-semibold py-4 rounded-xl hover:bg-slate-50 transition-colors">Atrás</button>
                  <button onClick={proceedToNextStep} disabled={loading} className="w-2/3 bg-emerald-700 text-white font-semibold py-4 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
                    {loading ? (
                      <><Loader2 size={18} className="animate-spin" /> Procesando...</>
                    ) : rol === "proveedor" ? "Siguiente" : "Crear Cuenta"}
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Provider Info (Only if Provider) */}
            {step === 3 && rol === 'proveedor' && (
              <div className="animate-fade-in space-y-5">
                <h2 className="text-lg font-semibold text-slate-800 border-b border-slate-100 pb-2">Cuéntanos sobre tu servicio</h2>

                {/* Combobox de comunas */}
                <div ref={comunaRef}>
                  <label className="block text-sm font-medium text-slate-700 mb-1">¿Dónde ofreces tus servicios? *</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={comunaQuery}
                      onChange={e => { setComunaQuery(e.target.value); setShowComunaList(true); }}
                      onFocus={() => setShowComunaList(true)}
                      placeholder="Escribe tu comuna..."
                      autoComplete="off"
                      className={inputClass}
                    />
                    {showComunaList && comunasFiltradas.length > 0 && (
                      <ul className="absolute z-20 left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg max-h-56 overflow-y-auto">
                        {comunasFiltradas.map(c => (
                          <li key={c}>
                            <button
                              type="button"
                              className="w-full text-left px-4 py-2.5 text-sm text-slate-800 hover:bg-emerald-50 hover:text-emerald-700 transition-colors"
                              onMouseDown={() => { setComunaQuery(c); setShowComunaList(false); }}
                            >
                              {c}
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>

                {/* Campos dinámicos por categoría */}
                {categoria && CAMPOS_POR_CATEGORIA[categoria] && (() => {
                  const CatIcon = CATEGORIA_ICONS[categoria] ?? Briefcase;
                  return (
                    <div className="bg-slate-50 rounded-xl border border-slate-200 p-5 space-y-4">
                      <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                        <CatIcon size={16} className="text-emerald-600" />
                        Información específica de tu servicio
                      </h3>
                      {(() => {
                        const camposVisibles = CAMPOS_POR_CATEGORIA[categoria].filter(function (campo) {
                          if (!campo.condicionalDe) return true;
                          var valorActual = datosDinamicos[campo.condicionalDe];
                          return valorActual === campo.condicionalValor;
                        });

                        return camposVisibles.map(campo => (
                          <div key={campo.key}>
                            <label className="block text-sm font-medium text-slate-700 mb-1">
                              {campo.label}{campo.requerido && <span className="text-red-500 ml-1">*</span>}
                            </label>
                            {campo.tipo === 'boolean' ? (
                              <label className="flex items-center gap-3 cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={!!datosDinamicos[campo.key]}
                                  onChange={e => setDatoDinamico(campo.key, e.target.checked)}
                                  className="w-5 h-5 rounded border-slate-300 accent-emerald-600"
                                />
                                <span className="text-sm text-slate-600">Sí</span>
                              </label>
                            ) : campo.tipo === 'select' ? (
                              <select
                                value={datosDinamicos[campo.key] || ''}
                                onChange={e => setDatoDinamico(campo.key, e.target.value)}
                                className={`${inputClass} cursor-pointer`}
                              >
                                <option value="" disabled>Selecciona...</option>
                                {campo.opciones?.map(op => (
                                  <option key={op.value} value={op.value}>{op.label}</option>
                                ))}
                              </select>
                            ) : (
                              <input
                                type={campo.tipo === 'number' ? 'number' : 'text'}
                                value={datosDinamicos[campo.key] || ''}
                                onChange={e => setDatoDinamico(campo.key, e.target.value)}
                                placeholder={campo.placeholder}
                                className={inputClass}
                              />
                            )}
                          </div>
                        ))
                      })()}
                    </div>
                  );
                })()}

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Cuéntanos sobre tu experiencia (opcional)</label>
                  <textarea
                    value={descripcion}
                    onChange={e => setDescripcion(e.target.value)}
                    maxLength={500}
                    rows={4}
                    placeholder="Ej: Tengo 5 años cuidando perros y gatos de raza..."
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 focus:bg-white placeholder:text-slate-400 transition-colors resize-none"
                  />
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-xs text-slate-500">Mínimo 50 caracteres. Una buena descripción aumenta tus consultas.</p>
                    <span className="text-xs text-slate-400">{descripcion.length} / 500</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="politica"
                    checked={aceptaPolitica}
                    onChange={e => setAceptaPolitica(e.target.checked)}
                    className="mt-1 rounded border-slate-300 accent-emerald-600 cursor-pointer"
                  />
                  <label htmlFor="politica" className="text-sm text-slate-600 cursor-pointer">
                    Entiendo que mi perfil será revisado por el equipo de Pawnecta y que debo cumplir con las{' '}
                    <Link href="/terminos" target="_blank" className="text-emerald-700 hover:underline">
                      políticas de publicación
                    </Link>
                    {' '}para mantener mi cuenta activa.
                  </label>
                </div>

                <div className="pt-2 flex gap-3">
                  <button onClick={() => setStep(2)} disabled={loading} className="w-1/3 border border-slate-300 text-slate-700 font-semibold py-4 rounded-xl hover:bg-slate-50 transition-colors">Atrás</button>
                  <button onClick={handleFinalSubmit} disabled={loading} className="w-2/3 bg-emerald-700 text-white font-semibold py-4 rounded-xl hover:bg-emerald-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
                    {loading ? (
                      <><Loader2 size={18} className="animate-spin" /> Creando cuenta...</>
                    ) : "Enviar Solicitud"}
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Success Message */}
            {step === 4 && (
              <div className="animate-fade-in text-center py-6">
                <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={40} />
                </div>
                <h2 className="text-2xl font-bold text-slate-800 mb-4">¡Registro Exitoso!</h2>

                {rol === 'usuario' ? (
                  <p className="text-slate-600 mb-8 max-w-md mx-auto">
                    Hemos enviado un mensaje de bienvenida a tu correo. Revisa tu bandeja de entrada o carpeta de spam para verificar tu cuenta y comenzar a explorar servicios.
                  </p>
                ) : (
                  <p className="text-slate-600 mb-8 max-w-md mx-auto">
                    Hemos recibido tu solicitud. Nuestro equipo revisará tus datos en las próximas 24-48 horas y te notificaremos por correo electrónico cuando tu perfil esté aprobado.
                  </p>
                )}

                <button
                  onClick={() => router.push('/')}
                  className="bg-emerald-700 text-white font-semibold py-3 px-8 rounded-xl hover:bg-emerald-800 transition-colors inline-block"
                >
                  Volver al Inicio
                </button>
              </div>
            )}

          </div>
        </div>

        {step < 4 && (
          <div className="mt-6 text-center text-sm text-slate-500">
            ¿Ya tienes cuenta?{" "}
            <Link href="/login" className="text-emerald-700 font-semibold hover:underline">
              Ingresa aquí
            </Link>
          </div>
        )}
      </main>


    </>
  );
}
