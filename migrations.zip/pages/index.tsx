import Head from "next/head";
import Link from "next/link";
import { useRouter } from "next/router";
import { useState } from "react";
import { GetStaticProps } from "next";
import { mapJoinToServiceResult } from "../lib/serviceMapper";
import { ServiceResult } from "../components/Explore/ServiceCard";
import { COMUNAS_CHILE } from "../lib/comunas";
import {
  Home, Sun, Footprints, MapPin, Scissors, Award, Stethoscope, Car,
  ShieldCheck, UserCheck, MessageCircle, Search, FileText, UserPlus, PlusCircle, Users, IdCard, ClipboardCheck, Star,
  CheckCircle2, Shield
} from "lucide-react";
import { supabase } from "../lib/supabaseClient";

import SearchBar from "../components/Home/SearchBar";
import ServiceCard from "../components/Home/ServiceCard";
import StepCard from "../components/Home/StepCard";
import TestimonialCard from "../components/Home/TestimonialCard";

// ─── PrelaunchDemandCapture ─────────────────────────────────────────────────
function PrelaunchDemandCapture() {
  const [email, setEmail] = useState('');
  const [comuna, setComuna] = useState('');
  const [done, setDone] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setDone(true);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 border-y border-slate-200">
      <div className="max-w-2xl mx-auto text-center">
        <h2 className="text-3xl font-black text-slate-900 mb-4">Sé el primero en enterarte</h2>
        <p className="text-slate-600 max-w-xl mx-auto mb-8">
          Estamos activando proveedores verificados en cada categoría y comuna. Deja tu correo y te avisamos cuando haya opciones disponibles cerca tuyo.
        </p>

        {done ? (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl px-8 py-10">
            <p className="text-emerald-800 font-bold text-lg">¡Listo! Te avisamos en cuanto haya proveedores en tu zona.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <input
              type="email"
              required
              placeholder="Tu correo electrónico"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="flex-1 h-12 px-4 border border-slate-200 rounded-xl bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 placeholder:text-slate-400 transition-colors"
            />
            <select
              value={comuna}
              onChange={e => setComuna(e.target.value)}
              className="h-12 px-4 border border-slate-200 rounded-xl bg-white text-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 transition-colors"
            >
              <option value="">Mi comuna...</option>
              {COMUNAS_CHILE.slice(0, 20).map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <button
              type="submit"
              className="h-12 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl transition-colors text-sm shrink-0"
            >
              Avisarme
            </button>
          </form>
        )}
        <p className="text-xs text-slate-400 mt-4">Sin spam. Solo te contactamos cuando tengamos proveedores disponibles.</p>
      </div>
    </section>
  );
}

const FALLBACK_HOME: Record<string, string> = {
  hospedaje: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400&auto=format&fit=crop&q=70",
  guarderia: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&auto=format&fit=crop&q=70",
  paseos: "https://images.unsplash.com/photo-1601979031925-424e53b6caaa?w=400&auto=format&fit=crop&q=70",
  domicilio: "https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=400&auto=format&fit=crop&q=70",
  peluqueria: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=400&auto=format&fit=crop&q=70",
  adiestramiento: "https://images.unsplash.com/photo-1535930891776-0c2dfb7fda1a?w=400&auto=format&fit=crop&q=70",
  veterinario: "https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?w=400&auto=format&fit=crop&q=70",
  traslado: "https://images.unsplash.com/photo-1544568100-847a948585b9?w=400&auto=format&fit=crop&q=70",
  default: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&auto=format&fit=crop&q=70",
};

function FranjaCategoria({
  categoria,
  servicios,
  onVerTodos,
}: {
  categoria: { slug: string; nombre: string; Icon: any };
  servicios: any[];
  onVerTodos: () => void;
}) {
  if (servicios.length === 0) return null;
  return (
    <div className="py-5">
      {/* Encabezado franja */}
      <div className="flex items-center justify-between mb-4 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <categoria.Icon className="w-5 h-5 text-emerald-600" />
          <h2 className="text-lg font-bold text-slate-900">{categoria.nombre}</h2>
          <span className="text-sm text-slate-400">disponibles</span>
        </div>
        <button
          onClick={onVerTodos}
          className="text-sm font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 transition-colors"
        >
          Ver todos <span>→</span>
        </button>
      </div>

      {/* Scroll horizontal */}
      <div className="flex gap-4 overflow-x-auto pb-3 px-4 sm:px-6 lg:px-8 scrollbar-hide
                      max-w-7xl mx-auto">
        {servicios.slice(0, 6).map((s: any) => {
          const foto = (s.fotos && s.fotos.length > 0) ? s.fotos[0]
            : s.proveedor_foto || FALLBACK_HOME[s.categoria_slug] || FALLBACK_HOME["default"];
          return (
            <a
              key={s.servicio_id ?? s.id}
              href={`/servicio/${s.servicio_id ?? s.id}`}
              className="shrink-0 w-44 group cursor-pointer"
            >
              <div className="w-44 h-44 rounded-xl overflow-hidden bg-slate-100 mb-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={foto}
                  alt={s.titulo}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  onError={(e) => {
                    const target = e.currentTarget as HTMLImageElement;
                    const fallback = FALLBACK_HOME[s.categoria_slug] || FALLBACK_HOME["default"];
                    if (target.src !== fallback) {
                      target.src = fallback;
                    } else if (target.src !== FALLBACK_HOME["default"]) {
                      target.src = FALLBACK_HOME["default"];
                    }
                  }}
                />
              </div>
              <p className="text-sm font-semibold text-slate-900 line-clamp-2 leading-snug
                            group-hover:text-emerald-700 transition-colors">
                {s.titulo}
              </p>
              {s.proveedor_comuna && (
                <p className="text-xs text-slate-500 mt-0.5">{s.proveedor_comuna}</p>
              )}
              {s.precio_desde > 0 && (
                <p className="text-sm font-bold text-slate-900 mt-1">
                  ${s.precio_desde.toLocaleString("es-CL")}
                  <span className="text-xs font-normal text-slate-400"> /{s.unidad_precio}</span>
                </p>
              )}
            </a>
          );
        })}

        {/* Card "Ver todos" al final */}
        <button
          onClick={onVerTodos}
          className="shrink-0 w-44 h-44 rounded-xl border-2 border-dashed border-slate-200
                     hover:border-emerald-400 flex flex-col items-center justify-center gap-2
                     text-slate-400 hover:text-emerald-600 transition-colors group"
        >
          <span className="text-3xl font-black group-hover:scale-110 transition-transform">→</span>
          <span className="text-xs font-semibold text-center px-3 leading-snug">
            Ver todos los {categoria.nombre.toLowerCase()}
          </span>
        </button>
      </div>
    </div>
  );
}

interface HomePageProps {
  featuredServices: any[];
  stats: {
    servicios: number;
    proveedores: number;
    comunas: number;
  };
  categoryCounts: Record<string, number>;
}

export default function HomePage({ featuredServices, stats, categoryCounts }: HomePageProps) {
  const router = useRouter();

  const categoriasEstaticas = [
    { slug: 'hospedaje', nombre: 'Hospedaje', descripcion: 'Tu mascota en un hogar de confianza', Icon: Home },
    { slug: 'guarderia', nombre: 'Guardería diurna', descripcion: 'Cuidado profesional durante el día', Icon: Sun },
    { slug: 'paseos', nombre: 'Paseo', descripcion: 'Paseos individuales o grupales cerca', Icon: Footprints },
    { slug: 'domicilio', nombre: 'Visita a domicilio', descripcion: 'El proveedor va a tu casa', Icon: MapPin },
    { slug: 'peluqueria', nombre: 'Peluquería', descripcion: 'Baño, corte y estética especializada', Icon: Scissors },
    { slug: 'adiestramiento', nombre: 'Adiestramiento', descripcion: 'Entrenamiento y corrección conductual', Icon: Award },
    { slug: 'veterinario', nombre: 'Veterinaria', descripcion: 'Consultas y atención médica cercana', Icon: Stethoscope },
    { slug: 'traslado', nombre: 'Traslado', descripcion: 'Transporte seguro para tu mascota', Icon: Car },
  ].map(cat => ({
    ...cat,
    count: categoryCounts[cat.slug] ?? 0,
    estado: ((categoryCounts[cat.slug] ?? 0) > 0 ? 'activa' : 'proxima') as 'activa' | 'proxima',
  }));

  const testimonios = [
    { nombre: "Valentina M.", ciudad: "Providencia, Santiago", mascota: "Border Collie", verificado: true, texto: "Encontré a la cuidadora de Nico en menos de diez minutos. Lo que más me convenció fue poder ver las reseñas y hablar directamente con ella antes de dejar a mi perro." },
    { nombre: "Rodrigo F.", ciudad: "Ñuñoa, Santiago", mascota: "Gato Maine Coon", verificado: true, texto: "Necesitaba alguien de confianza para Miso mientras viajaba. Pawnecta me permitió comparar opciones en mi comuna y elegir con calma. La comunicación fue directa y sin complicaciones." },
    { nombre: "Catalina R.", ciudad: "Las Condes, Santiago", mascota: "Golden Retriever", verificado: true, texto: "Me tranquiliza saber que los proveedores están verificados. Encontré paseador para Luna en el mismo barrio y quedé muy conforme con el servicio." },
    { nombre: "Ignacio V.", ciudad: "Maipú, Santiago", rol: "Paseador y proveedor", verificado: true, texto: "Publiqué mi servicio en menos de 20 minutos. Desde el primer día empecé a recibir consultas de dueños de mi misma comuna. Es la forma más simple que he encontrado de crecer." }
  ];

  return (
    <div className="bg-white">
      <Head>
        <title>Pawnecta — Servicios para mascotas en Chile | Proveedores verificados</title>
        <meta name="description" content="Encuentra cuidadores, paseadores, peluqueros y veterinarios verificados cerca de ti. Busca por comuna, compara perfiles y contacta directo. Gratis en lanzamiento." />
        <link rel="canonical" href="https://pawnecta.com" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://pawnecta.com" />
        <meta property="og:title" content="Pawnecta — Servicios para mascotas en Chile" />
        <meta property="og:description" content="Encuentra cuidadores, paseadores y veterinarios verificados cerca de ti." />
        <meta property="og:image" content="https://pawnecta.com/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Pawnecta — Servicios para mascotas en Chile" />
        <meta name="twitter:description" content="Proveedores verificados en tu comuna." />
        <meta name="twitter:image" content="https://pawnecta.com/og-image.jpg" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              "name": "Pawnecta",
              "url": "https://pawnecta.com",
              "potentialAction": {
                "@type": "SearchAction",
                "target": "https://pawnecta.com/explorar?q={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            })
          }}
        />
      </Head>

      {/* SECCIÓN 1: HERO + BUSCADOR */}
      <section
        aria-label="Buscador de servicios"
        className="relative min-h-[520px] flex items-center justify-center overflow-hidden bg-slate-900"
      >
        {/* Imagen de fondo */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=1600&auto=format&fit=crop&q=70"
          alt=""
          aria-hidden="true"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-40"
        />
        {/* Overlay degradado */}
        <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-900/50 to-slate-900/80" />

        {/* Contenido centrado */}
        <div className="relative z-10 w-full max-w-3xl mx-auto px-4 sm:px-6 text-center py-20">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white leading-tight mb-4 drop-shadow">
            Servicios para tu mascota,<br />
            <span className="text-emerald-400">cerca de ti</span>
          </h1>
          <p className="text-lg text-slate-200 mb-8 max-w-xl mx-auto">
            Proveedores verificados en tu comuna. Compara, contacta y coordina directo.
          </p>

          {/* SearchBar integrado — sin card blanca flotante */}
          <SearchBar variant="hero" />

          {/* CTA proveedor */}
          <p className="text-sm text-slate-300 mt-5">
            ¿Ofreces servicios para mascotas?{" "}
            <Link href="/register?rol=proveedor" className="text-emerald-400 font-semibold hover:underline">
              Publica gratis →
            </Link>
          </p>

          {/* Badges */}
          <div className="inline-flex flex-wrap justify-center gap-3 mt-6">
            {[
              { Icon: CheckCircle2, label: "Proveedores verificados" },
              { Icon: Shield, label: "Revisión por Pawnecta" },
              { Icon: MessageCircle, label: "Contacto directo" },
            ].map(({ Icon, label }) => (
              <div key={label} className="flex items-center gap-1.5 text-sm font-semibold text-white/90">
                <Icon className="w-4 h-4 text-emerald-400" />
                {label}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section aria-label="Categorias de servicio" className="py-8 px-4 sm:px-6 lg:px-8 border-b border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            {categoriasEstaticas.map((cat) => {
              const isProxima = cat.estado === "proxima";
              return isProxima ? (
                <div
                  key={cat.slug}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-slate-200 bg-slate-50 text-slate-400 text-sm font-semibold shrink-0 cursor-not-allowed opacity-60 select-none"
                >
                  <cat.Icon className="w-4 h-4" />
                  {cat.nombre}
                  <span className="text-[10px] font-bold bg-slate-200 text-slate-500 px-1.5 py-0.5 rounded-full">Pronto</span>
                </div>
              ) : (
                <button
                  key={cat.slug}
                  onClick={() => router.push(`/explorar?categoria=${cat.slug}`)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-full border border-slate-200 bg-white hover:border-emerald-500 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 text-sm font-semibold shrink-0 transition-all shadow-sm"
                >
                  <cat.Icon className="w-4 h-4 text-emerald-600" />
                  {cat.nombre}
                  {cat.count > 0 && (
                    <span className="text-[11px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                      {cat.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* SECCION 2.5: FRANJAS POR CATEGORIA — estilo MercadoLibre */}
      {(() => {
        const porCategoria: Record<string, any[]> = {};
        (featuredServices || []).forEach((s: any) => {
          const slug = s.categoria_slug || "default";
          if (!porCategoria[slug]) porCategoria[slug] = [];
          porCategoria[slug].push(s);
        });
        const categoriasActivas = categoriasEstaticas.filter(
          (c) => (porCategoria[c.slug] || []).length > 0
        );
        if (categoriasActivas.length < 2) return null;
        return (
          <section aria-label="Servicios por categoria" className="bg-white border-b border-slate-100 py-4">
            {categoriasActivas.map((cat) => (
              <FranjaCategoria
                key={cat.slug}
                categoria={cat}
                servicios={porCategoria[cat.slug] || []}
                onVerTodos={() => router.push(`/explorar?categoria=${cat.slug}`)}
              />
            ))}
          </section>
        );
      })()}
      {/* SECCIÓN 3: SERVICIOS DESTACADOS  — con 1+, o módulo pre-lanzamiento */}
      {featuredServices && featuredServices.length >= 1 ? (
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 border-y border-slate-200">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-black text-slate-900">Servicios disponibles</h2>
              <p className="text-slate-600 mt-3 text-lg">Proveedores verificados listos para ayudarte</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
              {featuredServices.map((service) => (
                <ServiceCard key={service.servicio_id ?? service.id} service={service} />
              ))}
            </div>
          </div>
        </section>
      ) : (
        <PrelaunchDemandCapture />
      )}

      {/* SECCIÓN 4: CÓMO FUNCIONA (DUEÑOS) */}
      <section aria-label="Como funciona para duenos de mascotas" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center border-b border-slate-100">
        <div className="mb-16">
          <p className="text-emerald-700 font-bold uppercase tracking-widest text-sm mb-3">Para dueños de mascotas</p>
          <h2 className="text-3xl font-black text-slate-900">Encuentra al proveedor ideal en minutos</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <StepCard
            paso={1}
            titulo="Busca por servicio y comuna"
            descripcion="Filtra por el servicio que necesitas y encuentra proveedores cerca de ti"
            Icon={Search}
            variante="light"
          />
          <StepCard
            paso={2}
            titulo="Compara perfiles y reseñas"
            descripcion="Revisa la experiencia, fotos y evaluaciones de cada proveedor"
            Icon={FileText}
            variante="light"
          />
          <StepCard
            paso={3}
            titulo="Contacta y coordina directo"
            descripcion="Escribe al proveedor por el chat interno y coordina los detalles"
            Icon={MessageCircle}
            variante="light"
          />
        </div>
      </section>

      {/* SECCIÓN 5: CONFIANZA — solo si hay 1+ proveedores activos */}
      {stats.proveedores >= 1 ? (
        <section aria-label="Verificacion de proveedores y testimonios" className="py-20 px-4 sm:px-6 lg:px-8 bg-white border-b border-slate-200">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-black text-slate-900 mb-10">Proveedores que puedes conocer</h2>

              <div className="flex flex-col md:flex-row justify-center items-start md:items-center gap-8 md:gap-12 bg-slate-900 p-8 md:px-12 rounded-3xl mb-12 max-w-5xl mx-auto text-left md:text-center">
                <div className="flex flex-col items-start md:items-center md:flex-1">
                  <IdCard className="w-8 h-8 text-emerald-400 mb-3" />
                  <h4 className="font-bold text-white mb-2">Verificación de identidad</h4>
                  <p className="text-sm text-slate-300">RUT validado y revisión manual del equipo Pawnecta antes de activar cada perfil</p>
                </div>
                <div className="hidden md:block w-px h-24 bg-slate-700"></div>
                <div className="flex flex-col items-start md:items-center md:flex-1">
                  <ClipboardCheck className="w-8 h-8 text-emerald-400 mb-3" />
                  <h4 className="font-bold text-white mb-2">Revisión del equipo</h4>
                  <p className="text-sm text-slate-300">El equipo de Pawnecta revisa y aprueba cada solicitud</p>
                </div>
                <div className="hidden md:block w-px h-24 bg-slate-700"></div>
                <div className="flex flex-col items-start md:items-center md:flex-1">
                  <Star className="w-8 h-8 text-emerald-400 mb-3" />
                  <h4 className="font-bold text-white mb-2">Reseñas reales</h4>
                  <p className="text-sm text-slate-300">Solo dueños que contactaron al proveedor pueden dejar evaluaciones</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {testimonios.map((testimonio, idx) => (
                <TestimonialCard key={`testimonio-${idx}`} {...testimonio} />
              ))}
            </div>
          </div>
        </section>
      ) : (
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-50 border-b border-slate-200">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-2xl font-black text-slate-900 mb-4">
              Únete a nuestra red de proveedores
            </h2>
            <p className="text-slate-600 mb-8">
              Sé de los primeros proveedores en ofrecer tus servicios en tu comuna
            </p>
            <Link
              href="/register?rol=proveedor"
              className="inline-flex items-center justify-center h-12 rounded-2xl bg-emerald-600 hover:bg-emerald-700 px-8 text-base font-semibold text-white shadow-sm transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:ring-offset-2"
            >
              Registrarse como proveedor
            </Link>
          </div>
        </section>
      )}

      {/* SECCIÓN 6: CÓMO FUNCIONA (PROVEEDORES) */}
      <section aria-label="Como funciona para proveedores" className="py-24 px-4 sm:px-6 lg:px-8 bg-slate-900 relative">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <p className="text-emerald-400 font-bold uppercase tracking-widest text-sm mb-3">Para proveedores</p>
            <h2 className="text-3xl md:text-4xl font-black text-white">Ofrece tus servicios en Pawnecta</h2>
            <p className="text-slate-300 mt-4 text-lg">Sin comisiones durante el lanzamiento</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <StepCard
              paso={1}
              titulo="Crea tu perfil"
              descripcion="Regístrate, verifica tu identidad y completa tu información profesional"
              Icon={UserPlus}
              variante="dark"
            />
            <StepCard
              paso={2}
              titulo="Publica tus servicios"
              descripcion="Describe lo que ofreces, define tu precio y activa tu vitrina"
              Icon={PlusCircle}
              variante="dark"
            />
            <StepCard
              paso={3}
              titulo="Recibe consultas directo"
              descripcion="Los dueños te contactan por el chat interno y tú coordinas todo"
              Icon={Users}
              variante="dark"
            />
          </div>

          <div className="text-center flex flex-col items-center">
            <Link
              href="/register?rol=proveedor"
              className="inline-flex items-center justify-center h-14 rounded-2xl border-2 border-white px-8 text-base font-semibold text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-slate-900 shadow-lg shadow-black/20"
            >
              Publicar mi servicio
            </Link>
            <p className="mt-4 text-slate-400 text-sm">Gratis durante el lanzamiento.</p>
          </div>
        </div>
      </section>

      {/* SECCIÓN 7: CTA FINAL + STATS */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto text-center relative">
          <h2 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">¿Buscas un servicio para tu mascota?</h2>
          <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto">Explora proveedores verificados en tu comuna ahora.</p>

          <button
            onClick={() => router.push('/explorar')}
            className="inline-flex items-center justify-center h-14 rounded-2xl bg-emerald-600 hover:bg-emerald-700 px-10 text-lg font-semibold text-white shadow-sm hover:-translate-y-0.5 hover:shadow-md transition-all focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:ring-offset-2 mb-4"
          >
            Buscar servicios
          </button>
          <p className="text-slate-500 font-medium mb-16">Sin registro. Sin costo.</p>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto border-t border-slate-200 pt-16">
            <div className="flex flex-col items-center justify-center p-4">
              <div className="text-5xl font-black text-emerald-700 mb-3 tracking-tighter">{stats.proveedores}</div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest text-center">Proveedores activos</div>
            </div>
            <div className="flex flex-col items-center justify-center p-4">
              <div className="text-5xl font-black text-emerald-700 mb-3 tracking-tighter">{stats.comunas}</div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest text-center">Comunas disponibles</div>
            </div>
            <div className="flex flex-col items-center justify-center p-4">
              <div className="text-5xl font-black text-emerald-700 mb-3 tracking-tighter">8</div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest text-center">Categorías de servicio</div>
            </div>
            <div className="flex flex-col items-center justify-center p-4">
              <div className="text-2xl font-black text-emerald-700 mb-3 tracking-tight leading-tight">Sin comisiones</div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-widest text-center">Durante el lanzamiento</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export async function getStaticProps() {
  // Query desde Supabase para servicios destacados
  let featuredServices: ServiceResult[] = [];
  try {
    const { data } = await supabase
      .from('servicios_publicados')
      .select('*, proveedor:proveedores(nombre, apellido_p, foto_perfil, comuna), categoria:categorias_servicio(nombre, icono, slug)')
      .eq('activo', true)
      .order('created_at', { ascending: false })
      .limit(6);
    if (data) {
      const mapped = data.map(mapJoinToServiceResult);
      // Prioritize services that have photos
      featuredServices = [
        ...mapped.filter(s => s.fotos && s.fotos.length > 0),
        ...mapped.filter(s => !s.fotos || s.fotos.length === 0),
      ].slice(0, 6);
    }
  } catch (error) {
    console.error("Error fetching featured services:", error);
  }

  let countServicios = 0;
  let countProveedores = 0;
  let comunasUnicas = new Set<string>();

  try {
    // 1. Total servicios activos
    const { count: sCount } = await supabase
      .from("servicios_publicados")
      .select("*", { count: "exact", head: true })
      .eq("activo", true);

    countServicios = sCount || 0;

    // 2. Total proveedores verificados
    const { count: pCount } = await supabase
      .from("proveedores")
      .select("*", { count: "exact", head: true })
      .eq("estado", "aprobado");

    countProveedores = pCount || 0;

    // 3. Comunas cubiertas únicas
    const { data: comunasData } = await supabase
      .from("proveedores")
      .select("comunas_cobertura, comuna")
      .eq("estado", "aprobado");

    if (comunasData) {
      comunasData.forEach(p => {
        // Prefer comunas_cobertura array; fallback to single comuna field
        const comunas = (Array.isArray(p.comunas_cobertura) && p.comunas_cobertura.length > 0)
          ? p.comunas_cobertura
          : (p.comuna ? [p.comuna] : []);
        comunas.forEach((c: string) => comunasUnicas.add(c));
      });
    }
  } catch (err) {
    console.error("Error fetching stats:", err);
  }

  const statsObj = {
    servicios: countServicios || 0,
    proveedores: countProveedores || 0,
    comunas: comunasUnicas.size || 0,
  };

  // Per-category service counts for CategoryCard estado/count badges
  let categoryCounts: Record<string, number> = {};
  try {
    const { data: catData } = await supabase
      .from('servicios_publicados')
      .select('categoria:categorias_servicio(slug)')
      .eq('activo', true);
    if (catData) {
      catData.forEach((row: any) => {
        const slug = row.categoria?.slug;
        if (slug) categoryCounts[slug] = (categoryCounts[slug] ?? 0) + 1;
      });
    }
  } catch (err) {
    console.error('Error fetching category counts:', err);
  }

  return {
    props: {
      featuredServices,
      stats: statsObj,
      categoryCounts,
    },
    revalidate: 30,
  };
}
